__version__ = "1.4.0"

from causal_conv1d.causal_conv1d_interface import causal_conv1d_fn, causal_conv1d_update
